<!doctype html>
<html class="no-js" lang="en">
	
<!-- Mirrored from rockstheme.com/rocks/aievari-live/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 03 Mar 2020 08:27:43 GMT -->
<head>
		<meta charset="utf-8">
		<meta http-equiv="x-ua-compatible" content="ie=edge">
		<title>Cointrana - a smart way to invest</title>
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<!-- favicon -->		
		<link rel="shortcut icon" type="image/x-icon" href="img/logo/favicon.png">

		<!-- all css here -->

		<!-- bootstrap v3.3.6 css -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- owl.carousel css -->
		<link rel="stylesheet" href="css/owl.carousel.css">
		<link rel="stylesheet" href="css/owl.transitions.css">
       <!-- Animate css -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- meanmenu css -->
        <link rel="stylesheet" href="css/meanmenu.min.css">
		<!-- font-awesome css -->
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/themify-icons.css">
		<link rel="stylesheet" href="css/flaticon.css">
		<!-- magnific css -->
        <link rel="stylesheet" href="css/magnific.min.css">
		<!-- style css -->
		<link rel="stylesheet" href="style.css">
		<!-- responsive css -->
		<link rel="stylesheet" href="css/responsive.css">

		<!-- modernizr css -->
		<script src="js/vendor/modernizr-2.8.3.min.js"></script>
		<style>
		    #scrollUp{
		        bottom:100px;
		    }
		    .dJpXjQ{
		        display:none;
		    }
		    .cg-flex cg-flex-row cg-justify-between cg-items-center cg-px-2 cg-py-1 cg-footer{
		        display:none;
		    }
		</style>
	
	</head>


<body>
<!--<a href="https://wa.me/31685105054"><img src="whatsappa.gif" width="70px" height="70px" style="position:fixed; bottom:30px; left:10px; z-index:1000;" alt=""></a>-->
<!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

<div id="preloader"></div>


<header class="header-one">
	<!-- Start top bar -->
	<div class="topbar-area fix hidden-xs">
		<div class="container">
			<div class="row">
			   <div class="col-md-6 col-sm-6">
				   <div class="topbar-left">
						<ul>
							<li><a href="#"><i class="fa fa-envelope"></i> support@cointrana.com</a></li>
							<li><a href="#"><i class="fa fa-phone"></i> +31685105054</a></li>
						</ul>
					</div>
				</div>
				<div class=" col-md-6 col-sm-6">
					<div class="topbar-right">
						<div class="top-social">
							<ul>
								<li><a href="#"><i class="fa fa-skype"></i></a></li>
								<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
								<li><a href="#"><i class="fa fa-google"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							</ul> 
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End top bar -->
	<div class="container-fluid">
        <div class="row">
        <!-- TradingView Widget BEGIN -->
            <div class="tradingview-widget-container">
            <div class="tradingview-widget-container__widget"></div>
            <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
            {
            "symbols": [
                {
                "proName": "FOREXCOM:SPXUSD",
                "title": "S&P 500"
                },
                {
                "proName": "FOREXCOM:NSXUSD",
                "title": "Nasdaq 100"
                },
                {
                "proName": "FX_IDC:EURUSD",
                "title": "EUR/USD"
                },
                {
                "proName": "BITSTAMP:BTCUSD",
                "title": "BTC/USD"
                },
                {
                "proName": "BITSTAMP:ETHUSD",
                "title": "ETH/USD"
                }
            ],
            "colorTheme": "dark",
            "isTransparent": false,
            "displayMode": "adaptive",
            "locale": "en"
            }
            </script>
            </div>
            <!-- TradingView Widget END -->
        </div>
    </div>
	<!-- header-area start -->
	<div id="sticker" class="header-area header-area-2 hidden-xs">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12">
					<div class="row">
						<!-- logo start -->
						<div class="col-md-3 col-sm-3">
							<div class="logo">
								<!-- Brand -->
								<a class="navbar-brand page-scroll white-logo" href="index.php">
									<img src="img/logo/cointranawhitelogo.png" alt="" width="150px">
								</a>
								<a class="navbar-brand page-scroll black-logo" href="index.php">
									<img src="img/logo/cointranablacklogo.png" alt="" width="150px">
								</a>
							</div>
							<!-- logo end -->
						</div>
						<div class="col-md-9 col-sm-9">
							<div class="header-right-link">
								<!-- search option end -->
								<a class="s-menu" style="float:left; padding:2px;" href="login">Login</a>
								<a class="s-menu" style="float:left; padding:2px;" href="signup">Signup</a>
							</div>
							<!-- mainmenu start -->
							<nav class="navbar navbar-default">
								<div class="collapse navbar-collapse" id="navbar-example">
									<div class="main-menu">
										<ul class="nav navbar-nav navbar-right">
											
											<li><a href="index.php">Home</a></li>
											<li><a href="aboutus.php">About us</a></li>
											<li><a href="contactus.php">Contact us</a></li>
											<!-- GTranslate: https://gtranslate.io/ -->
   <a href="#" onclick="doGTranslate('en|ar');return false;" title="Arabic" class="gflag nturl" style="background-position:-100px -0px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Arabic" /></a><a href="#" onclick="doGTranslate('en|en');return false;" title="English" class="gflag nturl" style="background-position:-0px -0px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="English" /></a><a href="#" onclick="doGTranslate('en|fr');return false;" title="French" class="gflag nturl" style="background-position:-200px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="French" /></a><a href="#" onclick="doGTranslate('en|de');return false;" title="German" class="gflag nturl" style="background-position:-300px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="German" /></a><a href="#" onclick="doGTranslate('en|it');return false;" title="Italian" class="gflag nturl" style="background-position:-600px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Italian" /></a><a href="#" onclick="doGTranslate('en|es');return false;" title="Spanish" class="gflag nturl" style="background-position:-600px -200px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Spanish" /></a>

<style type="text/css">
<!--
a.gflag {vertical-align:middle;font-size:16px;padding:1px 0;background-repeat:no-repeat;background-image:url(//gtranslate.net/flags/16.png);}
a.gflag img {border:0;}
a.gflag:hover {background-image:url(//gtranslate.net/flags/16a.png);}
#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}
-->
</style>
<select onchange="doGTranslate(this);"><option value="">Select Language</option><option value="en|af">Afrikaans</option><option value="en|sq">Albanian</option><option value="en|ar">Arabic</option><option value="en|hy">Armenian</option><option value="en|az">Azerbaijani</option><option value="en|zh-CN">Chinese (Simplified)</option><option value="en|zh-TW">Chinese (Traditional)</option><option value="en|hr">Croatian</option><option value="en|cs">Czech</option><option value="en|en">English</option><option value="en|et">Estonian</option><option value="en|tl">Filipino</option><option value="en|fr">French</option><option value="en|de">German</option><option value="en|el">Greek</option><option value="en|hi">Hindi</option><option value="en|hu">Hungarian</option><option value="en|is">Icelandic</option><option value="en|id">Indonesian</option><option value="en|ga">Irish</option><option value="en|it">Italian</option><option value="en|ja">Japanese</option><option value="en|mk">Macedonian</option><option value="en|ms">Malay</option><option value="en|pl">Polish</option><option value="en|pt">Portuguese</option><option value="en|sk">Slovak</option><option value="en|sl">Slovenian</option><option value="en|th">Thai</option><option value="en|tr">Turkish</option><option value="en|cy">Welsh</option><option value="en|yi">Yiddish</option></select><div id="google_translate_element2"></div>
<script type="text/javascript">
function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'en',autoDisplay: false}, 'google_translate_element2');}
</script><script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>


<script type="text/javascript">
/* <![CDATA[ */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',43,43,'||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'.split('|'),0,{}))
/* ]]> */
</script> 
										</ul>
									</div>
								</div>
							</nav>
							<!-- mainmenu end -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- header-area end -->
	<!-- mobile-menu-area start -->
	<div class="mobile-menu-area hidden-lg hidden-md hidden-sm" style="padding-top:0px;">
	    <div class="container-fluid">
	        <div class="row">
		        <div style="width:50%; float:left; padding:1%;">
					<a class="s-menu" style="float:left; padding:2px; text-align:center; width:100%;" href="login">Login</a>
		        </div>
		        <div style="width:50%; float:left; padding:1%;">
					<a class="s-menu" style="float:left; padding:2px; text-align:center; width:100%;" href="signup">Signup</a>
		        </div>
		    </div>
	    </div>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="mobile-menu">
						<div class="logo">
							<a href="index.php"><img src="img/logo/cointranablacklogo.png" alt="" /></a>
						</div>
						<nav id="dropdown">
							<ul>
								<li><a href="index.php">Home</a></li>
								<li><a href="aboutus.php">About us</a></li>
								<li><a href="contactus.php">Contact us</a></li>
								<li><a href="login">Signin</a></li>
								<li><a href="signup">Signup</a></li>
								<!-- GTranslate: https://gtranslate.io/ -->
   <a href="#" onclick="doGTranslate('en|ar');return false;" title="Arabic" class="gflag nturl" style="background-position:-100px -0px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Arabic" /></a><a href="#" onclick="doGTranslate('en|en');return false;" title="English" class="gflag nturl" style="background-position:-0px -0px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="English" /></a><a href="#" onclick="doGTranslate('en|fr');return false;" title="French" class="gflag nturl" style="background-position:-200px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="French" /></a><a href="#" onclick="doGTranslate('en|de');return false;" title="German" class="gflag nturl" style="background-position:-300px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="German" /></a><a href="#" onclick="doGTranslate('en|it');return false;" title="Italian" class="gflag nturl" style="background-position:-600px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Italian" /></a><a href="#" onclick="doGTranslate('en|es');return false;" title="Spanish" class="gflag nturl" style="background-position:-600px -200px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Spanish" /></a>

<style type="text/css">
<!--
a.gflag {vertical-align:middle;font-size:16px;padding:1px 0;background-repeat:no-repeat;background-image:url(//gtranslate.net/flags/16.png);}
a.gflag img {border:0;}
a.gflag:hover {background-image:url(//gtranslate.net/flags/16a.png);}
#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}
-->
</style>
<select onchange="doGTranslate(this);"><option value="">Select Language</option><option value="en|af">Afrikaans</option><option value="en|sq">Albanian</option><option value="en|ar">Arabic</option><option value="en|hy">Armenian</option><option value="en|az">Azerbaijani</option><option value="en|zh-CN">Chinese (Simplified)</option><option value="en|zh-TW">Chinese (Traditional)</option><option value="en|hr">Croatian</option><option value="en|cs">Czech</option><option value="en|en">English</option><option value="en|et">Estonian</option><option value="en|tl">Filipino</option><option value="en|fr">French</option><option value="en|de">German</option><option value="en|el">Greek</option><option value="en|hi">Hindi</option><option value="en|hu">Hungarian</option><option value="en|is">Icelandic</option><option value="en|id">Indonesian</option><option value="en|ga">Irish</option><option value="en|it">Italian</option><option value="en|ja">Japanese</option><option value="en|mk">Macedonian</option><option value="en|ms">Malay</option><option value="en|pl">Polish</option><option value="en|pt">Portuguese</option><option value="en|sk">Slovak</option><option value="en|sl">Slovenian</option><option value="en|th">Thai</option><option value="en|tr">Turkish</option><option value="en|cy">Welsh</option><option value="en|yi">Yiddish</option></select><div id="google_translate_element2"></div>
<script type="text/javascript">
function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'en',autoDisplay: false}, 'google_translate_element2');}
</script><script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>


<script type="text/javascript">
/* <![CDATA[ */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',43,43,'||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'.split('|'),0,{}))
/* ]]> */
</script> 
							</ul>
						</nav>
					</div>					
				</div>
			</div>
		</div>
	</div>
	
	<!-- mobile-menu-area end -->		
</header>
<!-- header end -->
	


        <!-- Start Intro Area -->
		<div class="slide-area fix" data-stellar-background-ratio="0.6">
            <div class="display-table">
                <div class="display-table-cell">
					<div class="container">
						<div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <!-- Start Slider content -->
                                <div class="slide-content text-center">
                                    <h2 style="padding-top:100px;" class="title2">The innovative platform for investors</h2>
                                    <div class="layer-1-3">
                                        <a href="signup" class="ready-btn left-btn" >Get started</a>
                                        <div class="video-content">
                                            <a href="https://youtube.com/watch?v=6Gu2QMTAkEU" class="video-play vid-zone">
                                                <i class="fa fa-play"></i>
                                                <span>watch video</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Slider content -->
						    </div>
						</div>
					</div>
				</div>
            </div>
		</div>
		<!-- End Intro Area -->

        <!-- about-area start -->
        <div class="about-area page-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <iframe width="100%" height="315" src="https://www.youtube.com/embed/6Gu2QMTAkEU?controls=0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                    <!-- column end -->
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div class="about-content">
							<h3>LET OUR EXPERTS <span>TRADE FOR YOU</span></h3>
                            <p>Cointrana, founded in 2017, Cointrana is a trading platform managed by a private trader who trades mostly Cryptocurrency. We have been trading for more than 6 years now and has a vast knowledge of the Crypto Online Market and Cryptocurrency Trading Investment. Cointrana is being known for it's transparency and accountability of managing finance in the world of Cryptocurrency Trading Investment and Account Management. We had a breakthrough in the market during the middle of 2018</p>
                            <div class="about-details">
                                <ul class="marker-list">
									<li>It is our mission to offer top notch services to all our investors, and to provide that service on the highest level possible</li>
									<li>We offer strategic ideas to our clients, we also provide the best possible support for realizing individual investment ideas.</li>
									
								</ul>
                            </div>
                        </div>
                    </div>
                    <!-- column end -->
                </div>
            </div>
        </div>
        <!-- about-area end -->


        <!-- Start Support-service Area -->
        <div class="support-service-area fix area-padding-2">
            <div class="container">
                <div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="section-headline text-center">
                            <h3>WHY INVESTORS TRUST US</h3>
						</div>
					</div>
				</div>
                <div class="row">
                    <div class="support-all">
                        <!-- Start About -->
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="support-services wow ">
                                <a class="support-images" href="#"><i class="flaticon-023-management"></i></a>
                                <div class="support-content">
                                    <h4>Finance Planning</h4>
                                    <p>We set a suitable platform which helps you achieve your goals financially.</p>
                                </div>
                            </div>
                        </div>
                        <!-- Start About -->
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="support-services ">
                                <a class="support-images" href="#"><i class="flaticon-036-security"></i></a>
                                <div class="support-content">
                                    <h4>Investment Management</h4>
                                    <p>Our professionals always accounts for best possible results.</p>
                                </div>
                            </div>
                        </div>
                        <!-- Start services -->
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="support-services ">
                                <a class="support-images" href="#"><i class="flaticon-003-approve"></i></a>
                                <div class="support-content">
                                    <h4>Risk Analysis</h4>
                                    <p>Constant market analysis to know when to call and when not to.</p>
                                </div>
                            </div>
                        </div>
                        <!-- Start services -->
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="support-services">
                                <a class="support-images" href="#"><i class="flaticon-042-wallet"></i></a>
                                <div class="support-content">
                                    <h4>Instant withdrawal</h4>
                                    <p>Earnings are transfered directly and instantly to user secure wallet</p>
                                </div>
                            </div>
                        </div>
                        <!-- Start services -->
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="support-services ">
                                <a class="support-images" href="#"><i class="flaticon-032-report"></i></a>
                                <div class="support-content">
                                    <h4>High Liquidity</h4>
                                    <p>Fast access to high liquidity orderbook for top currency pairs</p>
                                </div>
                            </div>
                        </div>
                        <!-- Start services -->
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="support-services">
                                <a class="support-images" href="#"><i class="flaticon-024-megaphone"></i></a>
                                <div class="support-content">
                                    <h4>24/7 Support</h4>
                                    <p>We are always available to support our investors by any means possible.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Support-service Area -->

        <!-- Start Invest area -->
        <div class="invest-area bg-color area-padding-2">
            <div class="container">
                <div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="section-headline text-center">
                            <h2>OUR INVESTMENT PLANS</h2>
                            
						</div>
					</div>
				</div>
                <div class="row">
                    <div class="pricing-content">
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="pri_table_list">
                                <center>
                                <h3>Basic Plan</h3>
                                <div class="top-price-inner">
                                   <div class="rates">
                                        <span class="prices">8%</span><span class="users">Profit Daily</span>
                                    </div>
                                </div>
                                <ol class="pricing-text">
                                    <li class="check">Minimum Invest : $100</li>
                                    <li class="check">Maximum Invest : $9,999</li>
                                    <li class="check">Capital Back in 5 Days</li>
                                    <li class="check">Instant withdrawal </li>
                                    <li class="check">Refund of a deposit</li>
                                    <li class="check">Profit based on the market</li>
                                </ol>
                                <div class="price-btn blue" style="width:100%;">
                                    <a style="width:100%;" class="blue" href="signup">Get Started</a>
                                </div>
                                </center>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="pri_table_list">
                                <center>
                                <h3>Standard Plan</h3>
                                <div class="top-price-inner">
                                    <span class="base">Recommended</span>
                                   <div class="rates">
                                        <span class="prices">10%</span><span class="users">Profit Daily</span>
                                    </div>
                                </div>
                                <ol class="pricing-text">
                                    <li class="check">Minimum Invest : $10,000</li>
                                    <li class="check">Maximum Invest : $49,999</li>
                                    <li class="check">Capital back in 12 Days</li>
                                    <li class="check">Instant withdrawal </li>
                                    <li class="check">Refund of a deposit</li>
                                    <li class="check">Profit based on the market</li>
                                </ol>
                                <div class="price-btn blue" style="width:100%;">
                                    <a style="width:100%;" class="blue" href="signup">Get Started</a>
                                </div>
                                </center>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="pri_table_list">
                                <center>
                                <h3>Premium Plan</h3>
                                <div class="top-price-inner">
                                   <div class="rates">
                                        <span class="prices">12.5%</span><span class="users">Profit Daily</span>
                                    </div>
                                </div>
                                <ol class="pricing-text">
                                    <li class="check">Minimum Invest : $50,000</li>
                                    <li class="check">Maximum Invest : Unlimited</li>
                                    <li class="check">Capital back in 30 Days</li>
                                    <li class="check">Instant withdrawal </li>
                                    <li class="check">Refund of a deposit</li>
                                    <li class="check">Profit based on the market</li>
                                </ol>
                                <div class="price-btn blue" style="width:100%;">
                                    <a style="width:100%;" class="blue" href="signup">Get Started</a>
                                </div>
                                </center>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- End Invest area -->

        
        <!-- Start Self-area -->
        <div class="self-area area-padding">
            <div class="container">
                <div class="row">
                    <!-- column end -->
                    <div class="col-md-6 col-sm-6 col-xs-12">
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="self-content">
							<h4 style="font-size:20px;">Bitcoin is one of the most important inventions in all of human history. For the first time ever, anyone can send or receive any amount of money with anyone else, anywhere on the planet, conveniently and without restriction. You should invest in bitcoin today</h4>
                            <span class="talk-text">Fedrick stone, CEO</span>
                        </div>
                    </div>
                    <!-- column end -->
                </div>
            </div>
        </div>
        <!-- End Self-area -->
        <!-- Start Work proses Area -->
        <div class="work-proses fix bg-color area-padding-2">
			<div class="container">
			    <div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="section-headline text-center">
                            <h3>STEPS TO START EARNING</h3>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="row">
							<div class="work-proses-inner text-center">
							    <div class="col-md-4 col-sm-4 col-xs-12">
                                    <div class="single-proses">
                                        <div class="proses-content">
                                            <div class="proses-icon point-blue">
                                                <span class="point-view">01</span>
                                                <a href="#"><i class="ti-briefcase"></i></a>
                                            </div>
                                            <div class="proses-text">
                                                <h4>Register with your email, activate your account and login
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End column -->
                                <div class="col-md-4 col-sm-4 col-xs-12">
                                    <div class="single-proses">
                                        <div class="proses-content">
                                            <div class="proses-icon point-orange">
                                               <span class="point-view">02</span>
                                                <a href="#"><i class="ti-layers"></i></a>
                                            </div>
                                            <div class="proses-text">
                                                <h4>Deposit money into your Cointrana investment wallet
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End column -->
                                <div class="col-md-4 col-sm-4 col-xs-12">
                                    <div class="single-proses last-item">
                                        <div class="proses-content">
                                            <div class="proses-icon point-green">
                                               <span class="point-view">03</span>
                                                <a href="#"><i class="ti-bar-chart-alt"></i></a>
                                            </div>
                                            <div class="proses-text">
                                                <h4>Choose from the investment plans and invest to start earning
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End column -->
							</div>
						</div>
                    </div>
				</div>
			</div>
		</div>
        <!-- End Work proses Area -->
        
        <!-- Start Feature Area -->
        <div class="feature-area bg-color fix area-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="feature-content">
                            <div class="feature-images">
                                <img src="img/referimage.jpg" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="feature-text">
                            <h3>Refer and earn today</h3>
						    <p>When you refer someone and the person makes a deposit , you get 10% of the first deposit that person makes</p>
                            
                            <a class="feature-btn" href="signup">Get started now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Feature Area -->
        
        
        <!--Start payment-history area -->
        <div class="payment-history-area bg-color fix area-padding-2">
            <div class="container">
               <div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="section-headline text-center">
                            <h3>Deposit and withdrawal history</h3>
						</div>
					</div>
                </div>
                                <div class="row">
                    <div class="col-md-12">
                        <div class="deposite-content">
                            <div class="diposite-box">
                                <h4>Last Transactions</h4>
                                <span><i class="flaticon-005-savings"></i></span>
                                <div class="deposite-table">
                                    <table>
                                        <tr>
                                            <th>Name</th>
                                            <th>Transaction</th>
                                            <th>Amount</th>
                                            <th>Currency</th>
                                        </tr>

                                        <tr>
                                        
                                            <td>
                                            Rege 
                                            </td>
                                            <td>
                                            WITHDRAW
                                            </td>
                                            <td>
                                            $124110
                                            </td>
                                            <td>
                                            Bitcoin
                                            </td>
                                        </tr>             
                                            <tr>
                                        
                                            <td>
                                            Anna Charlotte	 
                                            </td>
                                            <td>
                                            WITHDRAW
                                            </td>
                                            <td>
                                            $700
                                            </td>
                                            <td>
                                            Bitcoin
                                            </td>
                                        </tr>             
                                            <tr>
                                        
                                            <td>
                                            David Wilfredo Jimenez Santana	 
                                            </td>
                                            <td>
                                            WITHDRAW
                                            </td>
                                            <td>
                                            $
                                            </td>
                                            <td>
                                            Bitcoin
                                            </td>
                                        </tr>             
                                            <tr>
                                        
                                            <td>
                                            alisonrodriguez4446@gmail.com 
                                            </td>
                                            <td>
                                            DEPOSIT
                                            </td>
                                            <td>
                                            $10000
                                            </td>
                                            <td>
                                            Bitcoin
                                            </td>
                                        </tr>             
                                            <tr>
                                        
                                            <td>
                                            Jazmin  
                                            </td>
                                            <td>
                                            WITHDRAW
                                            </td>
                                            <td>
                                            $4571
                                            </td>
                                            <td>
                                            Bitcoin
                                            </td>
                                        </tr>             
                                                                                </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End payment-history area -->
        
        <!-- End reviews Area -->
        <div class="container-fluid">
            <div class="row" style="width:100%; overflow:scroll;">
                <script src="https://widgets.coingecko.com/coingecko-coin-converter-widget.js"></script>
                <coingecko-coin-converter-widget  style="width:100%" coin-id="bitcoin" currency="usd" background-color="#ffffff" font-color="#4c4c4c" locale="en"></coingecko-coin-converter-widget>
            </div>
         </div>
        
        
        
        <!-- Start Banner Area -->
        <div class="banner-area area-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="banner-all area-80 text-center">
                            <div class="banner-content">
                                <h3>Click the link below to purchase Crypto</h3>
                                <a class="banner-btn" href="https://blockchain.com">Blockchain.com</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner Area -->
        
        <!-- Start reviews Area -->
        <div class="reviews-area fix area-padding">
            <div class="container">
                <div class="row">
                    <div class="reviews-top">
                        <div class="col-md-5 col-sm-5 col-xs-12">
                            <div class="testimonial-inner">
                                <div class="review-head">
                                    <h3>Our customer say about our company work</h3>
                                    <p>It is our mission to offer top notch services to all our investors, and to provide that service on the highest level possible,We offer strategic ideas to our clients, we also provide the best possible support for realizing individual investment ideas.</p>
                                    <a class="reviews-btn" href="signup">Get Started</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                            <div class="reviews-content">
                                <!-- start testimonial carousel -->
                                <div class="testimonial-carousel item-indicator">
                                    <div class="single-testi">
                                        <div class="testi-text">
                                            <div class="clients-text">
                                                <div class="client-rating">
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                </div>
                                                <p>Following my involvement with this platform, I can unequivocally proclaim that it has been a cozy ride so far with an already achieved prospects, the level of services and organization here has no congruence,more success to Cointrana</p>
                                            </div>
                                            <div class="testi-img ">
                                                <img src="img/team/t3.jpg" alt="">
                                                <div class="guest-details">
                                                    <h4>Melik Diana</h4>
                                                    <span class="guest-rev">Clients - <a href="#">General customer</a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End single item -->
                                    <div class="single-testi">
                                        <div class="testi-text">
                                            <div class="clients-text">
                                                <div class="client-rating">
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                </div>
                                                <p>Cointrana is tested and trusted when it comes to looking for pro traders to trade for you, i have never regreted my journey with Cointrana.</p>
                                            </div>
                                            <div class="testi-img ">
                                                <img src="img/team/t4.jpg" alt="">
                                                <div class="guest-details">
                                                    <h4>Angel lima</h4>
                                                    <span class="guest-rev">Clients - <a href="#">General customer</a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End single item -->
                                    <div class="single-testi">
                                        <div class="testi-text">
                                            <div class="clients-text">
                                                <div class="client-rating">
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                </div>
                                                <p>Cointrana has helped me achieve alot even during the pandemic,I invested at the begining of the pandemic and have gotten returns three times now, I paid off my depth and enrolled my son in an online university </p>
                                            </div>
                                            <div class="testi-img ">
                                                <img src="img/team/t7.jpg" alt="">
                                                <div class="guest-details">
                                                    <h4>Rose Doil</h4>
                                                    <span class="guest-rev">Clients - <a href="#">General customer</a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End single item -->
                                    <div class="single-testi">
                                        <div class="testi-text">
                                            <div class="clients-text">
                                                <div class="client-rating">
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                    <a href="#"><i class="ti-star"></i></a>
                                                </div>
                                                <p>Cointrana has helped me leave life on my own terms , I paid off my depth and i am so happy i found Cointrana when i did.</p>
                                            </div>
                                            <div class="testi-img ">
                                                <img src="img/team/t6.jpg" alt="">
                                                <div class="guest-details">
                                                    <h4>Gabriel Hank</h4>
                                                    <span class="guest-rev">Clients - <a href="#">General customer</a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End single item -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End reviews Area -->
        <div class="container">
            <div class="row" style="height:300px;">
                <!-- TradingView Widget BEGIN -->
                <div class="tradingview-widget-container">
                  <div id="tradingview_3a76b"></div>
                  
                  <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
                  <script type="text/javascript">
                  new TradingView.MediumWidget(
                  {
                  "symbols": [
                    [
                      "COINBASE:BTCUSD|12M"
                    ]
                  ],
                  "chartOnly": false,
                  "width": "100%",
                  "height": "100%",
                  "locale": "en",
                  "colorTheme": "light",
                  "gridLineColor": "#F0F3FA",
                  "trendLineColor": "#2196F3",
                  "fontColor": "#787B86",
                  "underLineColor": "#E3F2FD",
                  "isTransparent": false,
                  "autosize": true,
                  "container_id": "tradingview_3a76b"
                }
                  );
                  </script>
                </div>
                <!-- TradingView Widget END -->
            </div>
         </div>
        
        
        
       
        
        <div class="container">
            <div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="section-headline text-center">
                            <h3>Latest Crypto News</h3>
						</div>
					</div>
                </div>
            <div class="row">
                <a style="pointer-events: none" class="fx-widget" data-widget="newsfeed" data-lang="en" data-post-date-color="#999" data-post-description-color="#333333" data-post-title-color="#333333" data-widget-bg-color="#FFF" data-show-image data-width="100%" data-height="400" data-show-date data-title-font-size="18" data-intro-font-size="16" data-show-upper-intro data-category="news" data-section="all" data-base-url="https://www.fxempire.com" data-url="//www.fxempire.com" href="https://www.fxempire.com" rel="nofollow" style="font-family:Helvetica;font-size:16px;line-height:1.5;text-decoration:none; pointer-events: none;"> <span style="color:#999999;display:inline-block; visibility:hidden; margin-top:10px;font-size:12px;">Powered By </span> <img style="width:87px; height:14px; visibility:hidden;" src="https://www.fxempire.com/logo-full.svg" alt="FX Empire logo" /> </a> <script async charset="utf-8" src="https://widgets.fxempire.com/widget.js" ></script>
            </div>
         </div>

         <div class="container">
            <div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="section-headline text-center">
                            <h3>Payment Methods we accept</h3>
						</div>
					</div>
                </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <img src="img/payment.png"  width="100%" alt="">
				</div>
            </div>
         </div>
        

        <!-- Start Footer Area -->
<footer class="footer1">
            <div class="footer-area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-5 col-sm-5 col-xs-12">
                            <div class="footer-content logo-footer">
                                <div class="footer-head">
                                    <div class="footer-logo">
                                    	<a class="footer-black-logo" href="#"><img src="img/logo/cointranablacklogo.png" alt=""></a>
                                    </div>
                                    
                                    <div class="subs-feilds">
                                        <div class="suscribe-input">
                                            <input type="email" class="email form-control width-80" id="sus_email" placeholder="Type Email">
                                            <button type="submit" id="sus_submit" class="add-btn">Subscribe</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end single footer -->
                        <div class="col-md-4 col-sm-3 col-xs-12">
                            <div class="footer-content">
                                <div class="footer-head">
                                    <h4>Services Link</h4>
                                    <ul class="footer-list">
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="aboutus.php">About us </a></li>
                                        <li><a href="contactus.php">Contact us</a></li>
                                    </ul>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- end single footer -->
                        <div class="col-md-3 col-sm-4 col-xs-12">
                            <div class="footer-content last-content">
                                <div class="footer-head">
                                    <h4>Information</h4> 
                                    <div class="footer-contacts">
										<p><span>Tel :</span> +31685105054</p>
										<p><span>Email :</span> support@Cointrana.com</p>
										<p><span>Location :</span> Broekstraat 10, 5393 KD Herpen, Netherlands</p>
									</div> 
                                    <div class="footer-icons">
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    <i class="fa fa-facebook"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa fa-twitter"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa fa-google"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa fa-pinterest"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa fa-instagram"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-area-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="copyright">
                                <p>
                                    Copyright © 2020
                                    <a href="#">Cointrana</a> All Rights Reserved
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- End Footer area -->
		
		<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ff7672ba9a34e36b96a2320/1erf6m35o';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
		<!-- all js here -->
        <script src="https://cdn.jsdelivr.net/gh/coinponent/coinponent@undefined/dist/coinponent.js"></script>
		<!-- jquery latest version -->
		<script src="js/vendor/jquery-1.12.4.min.js"></script>
		<!-- bootstrap js -->
		<script src="js/bootstrap.min.js"></script>
		<!-- owl.carousel js -->
		<script src="js/owl.carousel.min.js"></script>
		  <!-- stellar js -->
        <script src="js/jquery.stellar.min.js"></script>
		<!-- magnific js -->
        <script src="js/magnific.min.js"></script>
        <!-- wow js -->
        <script src="js/wow.min.js"></script>
        <!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- Form validator js -->
		<script src="js/form-validator.min.js"></script>
		<!-- plugins js -->
		<script src="js/plugins.js"></script>
		<!-- main js -->
		<script src="js/main.js"></script>
	</body>

<!-- Mirrored from rockstheme.com/rocks/aievari-live/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 03 Mar 2020 08:27:46 GMT -->
</html>